
    <!-- Footer -->
    <footer class="page-footer font-small blue">
    
<!-- Copyright -->
 

<div class="footer-copyright text-center py-3">    
   
 
 

   
</div>
<!-- Copyright -->


<div class="footer-copyright text-center py-3">    
 
 
 <a style="color:blue;" href="privicy.php">سياسة الخصوصية  </a>

   
</div>

</footer>