<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<a href=""  class="float_insta" target="_blank" id="insta_id">


<i class="fa fa-instagram my-float_insta"></i>
</a>






 







<style>



.float_insta{
	position:fixed;
	width:60px;
	height:60px;
	bottom:110px;
	right:40px;
	background-color:#C13584;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float_insta{
	margin-top:-16px;
}













.float_snap{
	position:fixed;
	width:60px;
	height:60px;
	bottom:110px;
	right:40px;
	background-color:#FFFC00;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float_snap{
	margin-top:-16px;
}


</style>


<script type="text/javascript">

 
    document.getElementById("insta_id").href= var phn="<?=$insta_url?>";; 
  
//alert(phn);

</script>