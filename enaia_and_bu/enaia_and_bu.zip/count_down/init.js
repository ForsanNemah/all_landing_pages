const efcc_countdown = new countdown({
  target: '.countdown',
  dayWord: ' يوم',
  hourWord: ' ساعة',
  minWord: ' دقيقة',
  secWord: ' ثانية'
});
