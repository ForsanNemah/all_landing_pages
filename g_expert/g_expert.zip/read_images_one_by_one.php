<?php

 
  
  
 echo "  <img   src='vpics/1.jpg' class='img-fluid' alt='Responsive image'   >  ";
 echo "  <img   src='vpics/2.jpg' class='img-fluid' alt='Responsive image'   >  ";
 echo "  <img   src='vpics/3.jpg' class='img-fluid' alt='Responsive image'   >  ";
 echo "  <img   src='vpics/4.jpg' class='img-fluid' alt='Responsive image'   >  ";
 echo "  <img   src='vpics/5.jpg' class='img-fluid' alt='Responsive image'   >  ";

?>