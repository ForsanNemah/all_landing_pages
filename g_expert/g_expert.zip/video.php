<video width="400" height="500" controls autoplay   muted loop>
  <source src="add.mp4" type="video/mp4">
 
 
</video>