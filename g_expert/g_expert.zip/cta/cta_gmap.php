<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


 





<a href="https://www.snapchat.com/add/anood_beauty" class="float_snap" target="_blank" id="gmap_id">


<i class="fa fa-snapchat my-float_snap"></i>
</a>







<style>



 













.float_snap{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	left:40px;
	background-color:#FFFC00;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float_snap{
	margin-top:-16px;
}


</style>


<script type="text/javascript">

 
    document.getElementById("gmap_id").href= var phn="<?=$gmap_url?>";
  
//alert(phn);

</script>