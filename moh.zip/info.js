 



var phn="966598123444";
var msg="تم التسجيل بنجاح ";
var user_id="2";
var action_url="https://script.google.com/macros/s/AKfycbzS7zYjbCAbBskLVP3caNUGq37lpjYA3xG9aZMZHjV1MB9DoHhtau68mvZT_a-UhUxSCw/exec";

 
//alert(phn);







 