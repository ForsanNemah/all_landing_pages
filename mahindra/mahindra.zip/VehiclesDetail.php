

<!DOCTYPE html >
<html lang="en">



<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="keywords" /><meta name="description" /><title>
	Vehicles Detail
</title>

    <!--Bootstrap -->

    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />

    <!--Custome Style -->

    <link rel="stylesheet" href="assets/css/style.css" type="text/css" /><link rel="stylesheet" href="assets/css/custom.css" type="text/css" />

    <!--OWL Carousel slider-->

    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css" /><link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css" />

    <!--slick-slider -->

    <link href="assets/css/slick.css" rel="stylesheet" />

    <!--bootstrap-slider -->

    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet" />

    <!--FontAwesome Font Style -->

    <link href="assets/css/fontawesome.min.css" rel="stylesheet" />



    <!-- SWITCHER -->

    <link rel="stylesheet" type="text/css" href="assets/switcher/css/switcher.css" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />



    <!-- Fav and touch icons -->

    <link rel="shortcut icon" href="assets/images/logo/favicon-48x48.ico" />

    <!-- Google-Font-->

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

<![endif]-->

<link href="App_Themes/Theme_Ar/fontfamily.css" type="text/css" rel="stylesheet" /><link href="App_Themes/Theme_Ar/Theme_Ar.css" type="text/css" rel="stylesheet" /></head>
<body class="index2">

    <div class="page-wrapper">

        <form method="post" action="./VehiclesDetail.aspx?ID=1" id="form" role="form" autocomplete="off">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value=" " />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form'];
if (!theForm) {
    theForm = document.form;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZDpQdIUWfUWblLHx2llNCxzTiz3q8rIrw1SlG64g5YihTxEsBg2&amp;t=638240097260000000" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvvSTvKszaxnqbPz_-DXGRrh6--ASuXVDBt8PX46evQQQMVklpYg8o4D9K3it7MPfj5XdJgnX37-VSZPj7cS0l9i9f2i55c1DsGBMtkBkK3WCfREoxwiCOOdfcUMDb3NE3634uKA1&amp;t=96346c8" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OOEGMXjf-Mh0VhhBD9Pdi3zBCl51XBH0PP4R4WxYMfih7IFh6hN4KisNC9Ele8QXfNccqGQDHmLR8hfQUwdSzf9wZ7Q75a8vkkLuO5QBxet0ClO4OwUB6ysZ4r2vhoErM45Nz1o1&amp;t=96346c8" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="12B622EF" />
</div>

            <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$smAjaxScriptManager', 'form', [], [], [], 999999, 'ctl00');
//]]>
</script>


            <!--Header-->
           <?php

include "nav.php";


?>

            <!-- /Header -->


            <section>
                
    <style type="text/css">
        #container {
            margin: auto;
            bottom: 0;
            left: 0;
            /*top: 0;*/
            right: 0;
            width: 200px;
            height: 119px;
            font: normal 18px Arial, Helvetica, sans-serif;
            line-height: 450px;
            text-align: center;
            color: white;
            overflow: hidden;
            cursor: pointer;
        }

        /*.modal-body {
            margin: auto;
            bottom: 0;
            left: 0;*/
        /* top: 0;*/
        /*right: 0;
            width: fit-content;
            height: fit-content;
            font: normal 18px Arial, Helvetica, sans-serif;
            line-height: 450px;
            text-align: center;
            color: white;
            overflow: hidden;
            cursor: pointer;
        }*/

        #spinImg {
            position: absolute;
            left: 0;
            /*top: 0;*/
            width: 7200px;
            height: 119px;
            visibility: hidden;
            border: none;
        }

        /* @media (min-width: 576px) {
            .modal-dialog {
                max-width: max-content;
                margin: 1.75rem auto;
            }
        }*/
    </style>

    <!--Listing-Image-Slider-->
    <section id="listing_img_slider">
        
                <div>
                    <img src='Images/Gallery/1fe78747-9610-4685-9d76-bd0b3f143565.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/9d153e3e-37d7-4706-9403-497d0055afd5.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/87b98de7-6c19-4d27-a1f6-d2f4d32e1a9a.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/a0f88ef4-6486-4427-9dc2-1f4cab1dd083.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/243bb54f-7013-4008-97eb-16880ef5be41.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/57f0016c-ba60-47ce-951d-7df64a9d72e3.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/46ede8a8-5dc5-4e7f-ac84-97f43192f253.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/89344f4e-e5cd-45cd-8e35-012fbdffca9d.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/35a23f48-1c9a-4ca7-a0cb-ba329f817262.png' class="img-fluid" alt="image">
                </div>
            
                <div>
                    <img src='Images/Gallery/7c894b3a-260f-4b37-bda8-0ca088ccf08e.png' class="img-fluid" alt="image">
                </div>
            
    </section>
    <!--/Listing-Image-Slider-->

    <section class="listing_other_info secondary-bg">
        <div class="container">
            
            <div id="other_info"><i class="fa fa-info-circle" aria-hidden="true"></i></div>
            <div id="info_toggle">
                <button type="button" data-bs-toggle="modal" data-bs-target="#schedule">
                    <i class="fa fa-car" aria-hidden="true"></i>
                    جدولة اختبار القيادة
                </button>
                <button type="button" data-bs-toggle="modal" data-bs-target="#make_offer">
                    <i class="fa fa-money" aria-hidden="true"></i>
                    طلب عرض
                </button>
                
                <button type="button" data-bs-toggle="modal" data-bs-target="#more_info">
                    <i class="fa fa-file-text-o" aria-hidden="true"></i>
                    طلب مزيد من المعلومات
                </button>
                <button type="button" data-bs-toggle="modal" data-bs-target="#View360" style="display: none;">
                    <i class="fa fa-file-text-o" aria-hidden="true"></i>
                    360°
                </button>
            </div>
        </div>
    </section>
    <!--Listing-detail-->
    <section class="listing-detail">
        <div class="container">
            <div class="listing_detail_head row">
                <div class="col-md-12">
                    <h3 class="title">
                        <span id="ContentPlaceHolder_lblProductName">ماهيندرا بيك أب</span></h3>
                    
                </div>
                
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="main_features">
                        <p>
                            <span id="ContentPlaceHolder_lblDesc"><div><br></div></span>
                        </p>
                        
                    </div>
                    <div class="listing_more_info">
                        <div class="listing_detail_wrap">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">SINGLE CAB </a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link" id="Technical-tab" data-bs-toggle="tab" href="#Technical" role="tab" aria-controls="Technical" aria-selected="true">DOUBLE CAB</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link" id="Accessories-tab" data-bs-toggle="tab" href="#Accessories" role="tab" aria-controls="Accessories" aria-selected="true">Accessories</a></li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content" id="myTabContent">
                                <!-- vehicle-overview -->
                                <div role="tabpanel" class="tab-pane active" id="home" aria-labelledby="home-tab">
                                    <div class="table-responsive">
                                        
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl00$hfSpecificationIdSingle" id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_0" value="1" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">TECHINICAL SPECIFICATIONS</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>شعبية</td>
                                                                    <td>4×4&4×2</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>الإطارات</td>
                                                                    <td>245/75R16</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>محرك</td>
                                                                    <td>2.2.L mHawk EV</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>قوة</td>
                                                                    <td>140 BHP</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عزم الدوران</td>
                                                                    <td>320 Nm</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>انتقال</td>
                                                                    <td>6MT320</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>التروس</td>
                                                                    <td>6 forward + 1 Reverse</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عجلات</td>
                                                                    <td>6,5J 16 (only steel)</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>البعد (الطول × العرض × الارتفاع)</td>
                                                                    <td>5175x1820x1860</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>أبعاد صندوق الأمتعة (الطول × العرض × الارتفاع)</td>
                                                                    <td>2294x1520x550</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>زاوية</td>
                                                                    <td>Approach 34</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تطهير الأرض</td>
                                                                    <td>210 MM</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>وزن إجمالي وزن المركبة</td>
                                                                    <td>3150</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تطويق</td>
                                                                    <td>1955Kg 2WD, 2055KG 4WD</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>دفع حمولة</td>
                                                                    <td>1195 & 1095KG FOR 2WD/4WD</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl01$hfSpecificationIdSingle" id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_1" value="2" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Safety</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>أكياس هواء أمامية مزدوجة</td>
                                                                    <td>ABS</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عمود توجيه قابل للانهيار</td>
                                                                    <td>مناطق تجعد الحماية من التصادم</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تنجيد مقاوم للحريق</td>
                                                                    <td>قفل مركزي بجهاز تحكم عن بعد وإنذار</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl02$hfSpecificationIdSingle" id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_2" value="3" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Comfort</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>تكييف</td>
                                                                    <td>مشغل سي دي Din2 و MP و USB و SD</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>قيادة</td>
                                                                    <td>عجلة القيادة - قابلة للإمالة</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>المرآة الخلفية</td>
                                                                    <td>نافذة إلكترونية</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>برنامج تشغيل WINDOW CONTROL بلمسة واحدة - والمبرمج (مضاد للقرص)</td>
                                                                    <td>السلطة النافذة</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>اتبعني المصابيح الأمامية</td>
                                                                    <td>مآخذ شحن 12 فولت</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>يستريح الذراع على المقاعد الأمامية</td>
                                                                    <td>كشافات أمامية مع مصابيح</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عجلات من سبائك</td>
                                                                    <td>تعمل بالطاقة</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>اختياري</td>
                                                                    <td>تحكم أوتوماتيكي بالكامل في المناخ</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>شاشة تعمل باللمس متكاملة نظام المعلومات والترفيه الملاحة عبر الأقمار الصناعية</td>
                                                                    <td></td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl03$hfSpecificationIdSingle" id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_3" value="4" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">OTHER FEATURE</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>مصباح الرأس</td>
                                                                    <td>الداخلية</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>أقواس بونيه هيدروليكيه</td>
                                                                    <td>الخطاف هوك</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>المقعد الخلفي</td>
                                                                    <td>الهالوجين</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>غني بالأسود</td>
                                                                    <td>For 4×4</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>جهاز عرض مزود بمصابيح حواجب</td>
                                                                    <td></td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>غني بالأسود</td>
                                                                    <td>For 4×4</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl04$hfSpecificationIdSingle" id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_4" value="5" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Style</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>مقابض أبواب مطلية</td>
                                                                    <td>شبكة أمامية مطلية (شعار إضافي كروم)</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>مصد أمامي مطلي</td>
                                                                    <td>المصد الخلفي المطلي</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>الكسوة</td>
                                                                    <td>اللوحات الطينية</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>رسم</td>
                                                                    <td></td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                    </div>
                                </div>

                                <!-- Technical-Specification -->
                                <div role="tabpanel" class="tab-pane" id="Technical" aria-labelledby="Technical-tab">
                                    <div class="table-responsive">
                                        
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationDouble$ctl00$hfSpecificationIdDouble" id="ContentPlaceHolder_rptSpecificationDouble_hfSpecificationIdDouble_0" value="1" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">TECHINICAL SPECIFICATIONS</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>شعبية</td>
                                                                    <td>4×4&4×2</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>الإطارات</td>
                                                                    <td>245/75R16</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>محرك</td>
                                                                    <td>2.2.L mHawk EV</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>قوة</td>
                                                                    <td>140 BHP</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عزم الدوران</td>
                                                                    <td>320 Nm</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>انتقال</td>
                                                                    <td>6MT320</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>التروس</td>
                                                                    <td>6 forward + 1 Reverse</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عجلات</td>
                                                                    <td>6,5J 16 (only steel)</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>البعد (الطول × العرض × الارتفاع)</td>
                                                                    <td>5175x1820x1915</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>أبعاد صندوق الأمتعة (الطول × العرض × الارتفاع)</td>
                                                                    <td>2294x1520x550</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>زاوية</td>
                                                                    <td>Breakover 18</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تطهير الأرض</td>
                                                                    <td>210 MM</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>وزن إجمالي وزن المركبة</td>
                                                                    <td>3150</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تطويق</td>
                                                                    <td>2055Kg 2WD, 2155KG 4WD</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>دفع حمولة</td>
                                                                    <td>1095 & 995KG FOR 2WD/4WD</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationDouble$ctl01$hfSpecificationIdDouble" id="ContentPlaceHolder_rptSpecificationDouble_hfSpecificationIdDouble_1" value="2" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Safety</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>أكياس هواء أمامية مزدوجة</td>
                                                                    <td>ABS</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عمود توجيه قابل للانهيار</td>
                                                                    <td>Crash Protection Crumple Zones</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تنجيد مقاوم للحريق</td>
                                                                    <td>Central Locking With Remote Control And Alarm</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationDouble$ctl02$hfSpecificationIdDouble" id="ContentPlaceHolder_rptSpecificationDouble_hfSpecificationIdDouble_2" value="3" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Comfort</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>تكييف</td>
                                                                    <td>CD Player Din2, MP, USB And SD</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>قيادة</td>
                                                                    <td>Steering Wheel -Tiltable</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>المرآة الخلفية</td>
                                                                    <td>Electronic Window</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>برنامج تشغيل WINDOW CONTROL بلمسة واحدة - والمبرمج (مضاد للقرص)</td>
                                                                    <td>Power Window</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>اتبعني المصابيح الأمامية</td>
                                                                    <td>12v Charging Sockets</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>يستريح الذراع على المقاعد الأمامية</td>
                                                                    <td>Front Headlamp With For Lamps</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>عجلات من سبائك</td>
                                                                    <td>Optional</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>قيادة</td>
                                                                    <td>Touch Screen Integrated infotainment And Satellite navigation</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>تحكم أوتوماتيكي في المناخ</td>
                                                                    <td>Powered</td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationDouble$ctl03$hfSpecificationIdDouble" id="ContentPlaceHolder_rptSpecificationDouble_hfSpecificationIdDouble_3" value="4" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">OTHER FEATURE</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>مصباح الرأس</td>
                                                                    <td>Interior</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>أقواس بونيه هيدروليكيه</td>
                                                                    <td>Pintle Hook</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>المقعد الخلفي</td>
                                                                    <td>Halogen</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>بروجيكتور مع لمبات الحاجب</td>
                                                                    <td></td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                                <input type="hidden" name="ctl00$ContentPlaceHolder$rptSpecificationDouble$ctl04$hfSpecificationIdDouble" id="ContentPlaceHolder_rptSpecificationDouble_hfSpecificationIdDouble_4" value="5" />
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2">Style</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                                <tr>
                                                                    <td>مقابض أبواب مطلية</td>
                                                                    <td>Painted Front Grille (Logo Addon Chrome)</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>مصد أمامي مطلي</td>
                                                                    <td>Painted Rear Bumper</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>الكسوة</td>
                                                                    <td>Mudflaps</td>
                                                                </tr>
                                                            
                                                                <tr>
                                                                    <td>رسم</td>
                                                                    <td></td>
                                                                </tr>
                                                            

                                                    </tbody>
                                                </table>
                                            
                                    </div>
                                </div>

                                <!-- Accessories -->
                                <div role="tabpanel" class="tab-pane" id="Accessories" aria-labelledby="Accessories-tab">
                                    <!--Accessories-->
                                        <div class="container">
                                            <div class="dealers_list_wrap">
                                                
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/76e8aa81-b15d-43af-8b1c-88bf2648d1dc.jpg' target="_blank">
                                                                <img src='Images/Gallery/76e8aa81-b15d-43af-8b1c-88bf2648d1dc.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/a9b22002-a981-4caf-82b2-699a79e93497.jpg' target="_blank">
                                                                <img src='Images/Gallery/a9b22002-a981-4caf-82b2-699a79e93497.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/451d688e-70c5-4d01-81c5-aafad232a8da.jpg' target="_blank">
                                                                <img src='Images/Gallery/451d688e-70c5-4d01-81c5-aafad232a8da.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/9e691b75-e45e-4152-b057-c22aee29c273.jpg' target="_blank">
                                                                <img src='Images/Gallery/9e691b75-e45e-4152-b057-c22aee29c273.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/181be5cd-5270-4206-8d83-effe896b0b4b.jpg' target="_blank">
                                                                <img src='Images/Gallery/181be5cd-5270-4206-8d83-effe896b0b4b.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/626475b4-abab-4c9e-a9b6-279da6950c8d.jpg' target="_blank">
                                                                <img src='Images/Gallery/626475b4-abab-4c9e-a9b6-279da6950c8d.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/5832bf36-5652-4bb7-9e25-d8bea3931e7b.jpg' target="_blank">
                                                                <img src='Images/Gallery/5832bf36-5652-4bb7-9e25-d8bea3931e7b.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/5d33459d-8172-486e-af3f-4a1604228499.jpg' target="_blank">
                                                                <img src='Images/Gallery/5d33459d-8172-486e-af3f-4a1604228499.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/50cb6ff7-9882-41cb-8622-adee5f386788.jpg' target="_blank">
                                                                <img src='Images/Gallery/50cb6ff7-9882-41cb-8622-adee5f386788.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/48b8f194-daf7-4004-a072-57eaed1702f0.jpg' target="_blank">
                                                                <img src='Images/Gallery/48b8f194-daf7-4004-a072-57eaed1702f0.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/5988dd71-91e7-425e-99e5-096d0c34f7de.jpg' target="_blank">
                                                                <img src='Images/Gallery/5988dd71-91e7-425e-99e5-096d0c34f7de.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                        <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo"><a href='Images/Gallery/6c3a630f-5e9f-4341-9da4-efbc210bf24e.jpg' target="_blank">
                                                                <img src='Images/Gallery/6c3a630f-5e9f-4341-9da4-efbc210bf24e.jpg' alt="image"></a> </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                                
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                                    
                                                

                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        
                    </div>

                </div>

                
            </div>



        </div>
    </section>

    <!--View360 -->
    <!--View360 -->
    <div class="modal fade" id="View360">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title">
                        360°</h3>
                </div>
                <div class="modal-body">
                    <!--Listing-detail-->
                    <section class="listing-detail" style="padding: 0;">
                        <div class="container">

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="listing_more_info" style="padding: 0;">
                                        <div class="listing_detail_wrap">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs" id="myTab1" role="tablist">
                                                <li class="nav-item" role="presentation"><a class="nav-link active" id="EXTERIOR-tab" data-bs-toggle="tab" href="#EXTERIOR" role="tab" aria-controls="EXTERIOR" aria-selected="true">الخارج </a></li>
                                                <li class="nav-item" role="presentation"><a class="nav-link" id="INTERIOR-tab" data-bs-toggle="tab" href="#INTERIOR" role="tab" aria-controls="INTERIOR" aria-selected="true">الداخلية</a></li>
                                                
                                            </ul>

                                            <!-- Tab panes -->
                                            <div class="tab-content" id="myTabContent1">
                                                <!-- vehicle-overview -->
                                                <div role="tabpanel" class="tab-pane active" id="EXTERIOR" aria-labelledby="EXTERIOR-tab">
                                                    <div id="container" onselectstart="return false;">

                                                     
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>



                        </div>
                    </section>

                </div>
            </div>
        </div>
    </div>
    <!--/View360 -->
    <!--/View360 -->

    <script>
        window.onload = function () {
            var imageTotal = 36, clicked = false, widthStep = 10, currPos, currImg = 0;
            var imageLeft = 0; imageWidth = $('#spinImg').width(), imageFrame = $('#container').width();
            $('#spinImg').css('visibility', 'visible');
            $("#View360").on('mousedown touchstart', function (e) {
                currPos = (e.type == "touchstart") ? window.event.touches[0].pageX : e.pageX; clicked = true; return false;
            }); // end mousedown

            $("#View360").on('mouseup touchend', function () { clicked = false; }).on('mousemove touchmove', function (e) {
                if (clicked) {
                    var pageX = (e.type == "touchmove") ? window.event.targetTouches[0].pageX : e.pageX;
                    if (Math.abs(currPos - pageX) >= widthStep) {
                        if (currPos - pageX >= widthStep) {
                            currImg++;
                            imageLeft = imageLeft - imageFrame;
                            if (currImg >= imageTotal) { currImg = 1; imageLeft = 0; }
                        } else {
                            currImg--;
                            imageLeft = imageLeft + imageFrame;
                            if (imageLeft > 0) { currImg = imageTotal, imageLeft = -imageWidth + imageFrame }
                        }
                        $('#spinImg').css('left', imageLeft + 'px');
                        currPos = pageX;
                    }
                }  // end clicked
            }); // end mousemove
        }; //end load
    </script>


            </section>
            <!-- main-container -->


            <!--Footer -->

            <footer>

                <div class="footer-top">

                    <div class="container">

                        <div class="row">
                            <div class="col-md-6 col-sm-6">

                                <h6>
                                    <span id="lblmahindrauae">ماهيندرا </span></h6>

                                <div class="newsletter-form">
                                    
                                    <div class="navbar-header">
                                        <div class="logo">
                                            <a href="Home.aspx">
                                                <img src="assets/images/logo/Mahindra-Logo_Red.png" width="200" />
                                                
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-6 col-sm-6">

                                <h6>
                                    <span id="lblMainPage">الصفحات الرئيسية</span></h6>

                                <ul>
                                    <li>
                                        <a href="Home.aspx">
                                            <span id="lblHomeFooter">الصفحة الرئيسية</span></a>
                                    </li>
                                    <li><a href="About.aspx">
                                        <span id="lblAboutUsFooterLink">معلومات عن الشركة</span></a></li>
                                    <li><a href="Vehicles.aspx">
                                        <span id="lblVehiclesFooter">السيارات</span></a></li>
                                    <li><a href="DealerLocator.aspx">
                                        <span id="lblDealerLocatorFooter">فروعنا</span></a></li>
                                    <li><a href="Contact.aspx">
                                        <span id="lblContactusFooter">اتصل بنا</span></a></li>

                                    
                                </ul>

                            </div>

                            



                        </div>

                    </div>

                </div>

                <div class="footer-bottom">

                    <div class="container">

                        <div class="row">



                            <div class="col-md-6">

                                <p class="copy-right">
                                    <span id="lblCopyright">جميع الحقوق محفوظه &copy; 2023 mahindra.</span></p>

                            </div>

                            <div class="col-md-6 text-right">

                                

                                <div class="footer_widget">

                                    <p>
                                        <span id="lblConnectwithUs">اتصل بنا:</span></p>

                                    <ul>

                                        <li><a href="https://www.facebook.com/profile.php?id=100086457727248" id="lbfacebook" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>

                                        <li><a href="https://twitter.com/mahindra_saudi" id="lbtwitter" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>

                                        <li><a href="https://www.snapchat.com/add/mahindra_saudi?share_id=o83NEKg_4Fc&locale=en-JO" id="lbsnapchat" target="_blank"><i class="fa fa-snapchat" aria-hidden="true"></i></a></li>

                                        <li><a href="https://www.instagram.com/mahindra_saudi?r=nametag" id="lbinstagram" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                        <li><a  href="https://www.youtube.com/channel/UC3jTMgwOWIMX1HkU8u-YqDA" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                                        <li><a  href="http://tiktok.com/@mahindra_saudi" target="_blank"><i class="fab fa-tiktok" aria-hidden="true"></i></a></li>

                                    </ul>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </footer>

            <!-- /Footer-->


            <!--Back to top-->
            <div id="back-top" class="back-top"><a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i></a></div>
            <!--/Back to top-->



            <!--Register-Form -->

            <div class="modal fade" id="signupform">

                <div class="modal-dialog modal-lg" role="document">

                    <div class="modal-content">

                        <div class="modal-header">

                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                            <div style="text-align: center;">
                                <a href="Home.aspx">
                                    <img src="assets/images/logo/Mahindra-Logo.png" width="200" />
                                    </a>
                            </div>
                            <h6 class="modal-title" style="text-align: center;">
                                <span id="lblLetuscallyouandtellyoumoreaboutouroffers">دعنا نتصل بك ونخبرك المزيد عن عروضنا</span></h6>
                            <h3 class="modal-title" style="text-align: center; color: #fa2837;">
                                <span id="lblRequestACallback">طلب استدعاء</span></h3>

                        </div>

                        <div class="modal-body">



                            <div class="signup_wrap">

                                <div class="row">

                                    <div class="col-md-12 col-sm-12">

                                        <div action="#" method="get">

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Full Name">
                                            </div>

                                            <div class="form-group">

                                                <input type="email" class="form-control" placeholder="Email Address">
                                            </div>

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Phone Number">
                                            </div>

                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="">
                                                        <span id="Label24">اتصل بنا</span>Please Select Location</option>
                                                    <option value="DUBAI DEIRA">
                                                        <span id="lblDUBAIDEIRA">دبي ديره</span></option>
                                                </select>
                                                
                                            </div>
                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="Mahindra PIK UP">
                                                        <span id="lblMahindraPIKUP">ماهيندرا بيك أب</span></option>
                                                </select>
                                            </div>
                                            <div class="form-group">

                                                <input type="submit" value="Sign Up" class="btn btn-block">
                                            </div>

                                        </div>

                                    </div>

                                    
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <!--/Register-Form -->


            <!--Schedule-Test-Drive -->
            <div class="modal fade" id="schedule">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblScheduleTestDrive">اختبار القيادة</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$fullName" type="text" id="fullName" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Email" type="email" id="Email" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Phone" type="text" id="Phone" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestTime" type="text" id="BestTime" class="form-control" placeholder="الوقت المفضل (00:00 صباحا)" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestDate" type="text" id="BestDate" class="form-control" placeholder="اليوم المفضل (يوم/شهر/سنة )" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Message" id="Message" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$SubmitSchedule" type="submit" id="SubmitSchedule" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Schedule-Test-Drive -->

            <!--Make-Offer -->
            <div class="modal fade" id="make_offer">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblMakeanOffer">طلب عرض</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemake_offer" type="text" id="FullNamemake_offer" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmake_offer" type="email" id="EmailAddressmake_offer" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermake_offer" type="text" id="PhoneNumbermake_offer" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$OfferPricemake_offer" type="text" id="OfferPricemake_offer" class="form-control" placeholder="سعر العرض" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messageemake_offer" id="Messageemake_offer" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmake_offer" type="submit" id="Submitmake_offer" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Make-Offer -->

            <!--Email-to-Friend -->
            <div class="modal fade" id="email_friend">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblEmailtoFriend">أرسل إلى صديق</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email Address">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Friend Email Address">
                                </div>
                                <div class="form-group">
                                    <textarea rows="4" class="form-control" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Submit Query" class="btn btn-block">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Email-to-Friend -->

            <!--Request-More-Info -->
            <div class="modal fade" id="more_info">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblRequestMoreInfo">طلب مزيد من المعلومات</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemore_info" type="text" id="FullNamemore_info" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmore_info" type="email" id="EmailAddressmore_info" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermore_info" type="text" id="PhoneNumbermore_info" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messagemore_info" id="Messagemore_info" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmore_info" type="submit" id="Submitmore_info" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Request-More-Info -->

        </form>
    </div>

    <!-- Scripts -->

   

<!-- Scripts --> 

<script src="assets/js/jquery.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script> 

<script src="assets/js/interface.js"></script> 

<script src="assets/js/31f5977fdc.js"></script>

<!--Switcher-->

<script src="assets/switcher/js/switcher.js"></script>

<!--bootstrap-slider-JS--> 

<script src="assets/js/bootstrap-slider.min.js"></script> 

<!--Slider-JS--> 

<script src="assets/js/slick.min.js"></script> 

<script src="assets/js/owl.carousel.min.js"></script>
    
    <script>
        //$(document).ready(function () {
        //    debugger;
        //    var loadTime = new Date();
        //    $(document).mouseleave(function () {
        //        var leaveTime = new Date();
        //        var diff = leaveTime - loadTime;
        //        var sec = diff / 1000;
        //        if (sec > 10) {
        //            $('#signupform').addClass("show");
        //            $('#signupform').attr('aria-modal', 'true');
        //            $('#signupform').attr('role', 'dialog');
        //            $('#signupform').css('display', 'block');
        //            $('body').addClass('modal-open');
        //            $('body').css('overflow', 'hidden');
        //            $('body').css('padding-right', '17px');
        //            $('body').append('<div class="modal-backdrop fade show"></div>');

        //        }
        //        loadTime = new Date();
        //    });

        //});
    </script>
</body>
</html>
