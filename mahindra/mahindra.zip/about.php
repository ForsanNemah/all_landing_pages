

<!DOCTYPE html >
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="keywords" /><meta name="description" /><title>
	حول
</title>

    <!--Bootstrap -->

    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />

    <!--Custome Style -->

    <link rel="stylesheet" href="assets/css/style.css" type="text/css" /><link rel="stylesheet" href="assets/css/custom.css" type="text/css" />

    <!--OWL Carousel slider-->

    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css" /><link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css" />

    <!--slick-slider -->

    <link href="assets/css/slick.css" rel="stylesheet" />

    <!--bootstrap-slider -->

    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet" />

    <!--FontAwesome Font Style -->

    <link href="assets/css/fontawesome.min.css" rel="stylesheet" />



    <!-- SWITCHER -->

    <link rel="stylesheet" type="text/css" href="assets/switcher/css/switcher.css" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />



    <!-- Fav and touch icons -->

    <link rel="shortcut icon" href="assets/images/logo/favicon-48x48.ico" />

    <!-- Google-Font-->

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

<![endif]-->

<link href="App_Themes/Theme_Ar/fontfamily.css" type="text/css" rel="stylesheet" /><link href="App_Themes/Theme_Ar/Theme_Ar.css" type="text/css" rel="stylesheet" /></head>
<body class="index2">

    <div class="page-wrapper">

        <form method="post" action="./About.aspx" id="form" role="form" autocomplete="off">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="ipMxmYZrfeMCexVVg4M15kGHk9+N3FUUyckXxgqMKIJXj7Ge6kxCT+bUa7kMtSYbU54pYjwoIDRYup7MswB7xD5efhEdDOHJIeSo5Vw8CGT+/GaWEC6fYyfzdIRehnPOvhw3fhy4BGu+vWbHyE/ZNtdKrmV/EHmHOvesrBGQv9Q4EvWXPisg+TNXQBcYQrXXgGX2zxDrxvHCFroXOSZ9hwmGukyhTVmaKnMMVidfTtuuhjBOjLULY3ng6kuaE1Afrc9oB36tZZPP238e732mgX6yZDKCakwkUQN3RPR2n7pF8i10COK5K1fofi4USP438ozwaxk8wwSTN8cpJ8/ZNKZYzcnNmbfVr1R/stZDqcannPvY5fap3CwIN82BHX6ii0Pd1ovtjN0foeEqoKM/YFB8KeV+eMBJwy8fsxWk5znUZlxn1aX5SoxiNNgB5s5m5bZ8Y+2578lLXnoxntO3pxCs83jufgTuG7bTCuCX3N/lmaJUc/q7Zej+G/xX+mA0MiAXv7X0YFhnb896nO4xSdFA9MZgR+yfBx6N34Qa261XNBgZQ0pXAtn6NrDatbc9wFaxBAbYL3Mn9hxN8lZXvshBRL0J7IaBVrTAiEMihlG3Gp4LD+oEGiqSoMZccKlBDZAFH2yCyEVSInukjhMoDWPEGYY5WIarX9/LSHwwDpU4x+zf3pcelu/8EAnfgwQrgT8Zw99xP5HQsDjlB+dGFN9MkjqJz0i98yKNpLFgeKZLNqBkH89zP+IFUAE2VBJbP1Eb7b16HrkAa3YxIP5fP5tCWqA9pFemg16t0Su3K66BEI10mQl8oO4VCo8XveDmOnMC9E1j+Ky3bTnSEcyF3aQB3p950qLBs0hEA9JOOmXak1pHr1RmRvn90loR7RInSoJoOAE/oPzI8pTfRW/US0g5d9wm/M//XbMezs2eE/nNS7noV3F3ruuyV2Lce5iOXmNqoPVmntcXn5L4Ndp+UN7E/ZKBPwROeQ4kcSxl6c9MpgY2swB2xUZ5jyVOtwlxmr3XJljuvgQ/8KROp2Oo1Pn4TEnnSXRlppOoKDUPtToeOwiNiN6ZpqTkWMuDZX5CSYgDQnzdyjmyBbC3WoY7H18r8VS4vqYluulyHEApbPx2W7FwbG9hkmSXxMNGyo1C6ZOXt013d9GjE7RXEz8enZVUJbO7qBVbFtwe5u0HSSyf0G1AVmzY5xcmcArNI/8o0bU2XvchvtUsPmwxkSW63VUp64FO1vPSaWNXbKoPkWjDAjWh9WhGocWzh3cPIcYpxtMlhBmGzdO1tHXar90NGNOGOBvwE2648UDEapFOCI6eIoPVQFG8F0rFwe1oU/A9JDJM+s+yZG2hytWsDrK538eRIq53AvtcjJT8kZcvDKh7z8zd3JtEy5OyuK3sGOtrErpJxTFgzCNgx5ZSv6AG3g4lKOFW3UgkmVhMiDvlvSn+KRm7EuTHSQc5+yoPL9HjiytQlWQFxxYxmArELM4XWTY7D9Nm5B/pdmkNn6O9TZF38dpcJ43rO1b0g8m3F3FNgB9RPgeVFXOrBnrc9P+We6ni2gYpxzRg97FnYpHIugFfKkNXYXf1ZKQB/tIvZOrNTLVVIGKacOElCsGy1miIlKApsnMoBgzvIS6X0RCitMZLjjpX5yYyeYpDNt9ORNoU2H8pHFEFOBgclfZrrILD1N0LDHf5b91J/10iT/mdtuTk1JCmuuowK/RDEnsb3cfQ5Wqwr5DvlSq+KNlDNb8oZiJ2XgJPpsQ1MWTCi3y1ZVQYd5TIPgNIO8DGSDL2s7cQcIYQ+KdkeWwMEks2sdXkVdH+xAxPIU07Rr0wXEh5CnBQ7sPajQZ3i607ohs9HwPh+lAOtW0xnjyuot7f1UyrHl+0Qqe3GIMG1lspVZlNeeczetU6nq61Rfj4u9YKFekqqxkC+9RWkLLBrDbWJD6E8MzT4zpDpIuFuJ1cgSSimOjfeEIpWpm84WkSBh15jZvysovtZ+0ogCjXt0N9NUE0PV9qbtdrAhrq+/mqFbJBfESzhDsHnJPmhN5B+tMcDBfW46WuWkbLro67+L06S/bTfCRczzB0s5muFbK7JSE4o99NGcfHOn+r+EFXoLHm7pIpEO9PUCTFLbQ9k/15V6SKMnqciA2DvnBNt6pExA1y1kvz2NzaklmgEl2LbzC4iWabUWjeCqYCLw74tLEm2qk6ccE+PtkrcJ9vg1nvk4FARMnHGPfyM7qtofvkkirUzKC2h+5Z0bN23job4uCBhQ6Rbp8V0Rc0J59+jEL0VBSpwrex+I/Dcy26zgqMTpOdJNRHxcPNZZdCqc10Tx2Tngb2VFNypNewy9nPsQytx3Os9biBfmhSpK1p5t4j0qSIBcBt77VPOHtozf7UJC8u/LOrGHSL+NtCwP98qywHJZtFhHH8nqpxXy9mX6VZ+GyGGoOCBgOppv3WtklZ2Ho/RqW5YZr7/AxxK3cJlEDGEy9InsQ4zWYoYefJtzLYBqnzXPchfL2gtVYob+GGUnA0nESMdZq3EJ7xHO6T8Rm9ezbDpXOThADaS2/vV59NxdfV4IaLzL4/3us5EHsv3imjTZ7emwpJwjBXLirgYcPHa1OEOhJUue9f1ttshLscGe1PeLQC6FAxGz8RORsude9jUH2R+AXklxr6oxKQftE+pL18g2rabCBPNzUph4BsQIt2fyxAsdMX1Htcj+uc0oqqO7MxEX66rutjyHtrjV7sc0gHqw2xrcW+LAaImewWqUOXkcZcIgLYFbaS1fYM6kZ6hNgmX+hd+tqo8MRskFV+bvPLJyMtmi4PkNUnKnZ2WXCj7uzm9nF8SrTwhq5s/XEvNNTuPsBqnGXKtyUGO4xC6IcfRS3irUWFJ2T+nqHZ0q0kZruAhhjOcainUdHme/WZ49urlk2wzUYeOJ8hv6jHkBRR3srWvM0/Ky0yG2EZuQR5fKu+QSejuERWoVSypyS/9lbVrWNPae/kdV4layJ/PloZIsl61MsihG7WO3xTIJSI3qS+oCO2XA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form'];
if (!theForm) {
    theForm = document.form;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZDpQdIUWfUWblLHx2llNCxzTiz3q8rIrw1SlG64g5YihTxEsBg2&amp;t=637814372020000000" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvvSTvKszaxnqbPz_-DXGRrh6--ASuXVDBt8PX46evQQQMVklpYg8o4D9K3it7MPfj5XdJgnX37-VSZPj7cS0l9i9f2i55c1DsGBMtkBkK3WCfREoxwiCOOdfcUMDb3NE3634uKA1&amp;t=49337fe8" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OOEGMXjf-Mh0VhhBD9Pdi3zBCl51XBH0PP4R4WxYMfih7IFh6hN4KisNC9Ele8QXfNccqGQDHmLR8hfQUwdSzf9wZ7Q75a8vkkLuO5QBxet0ClO4OwUB6ysZ4r2vhoErM45Nz1o1&amp;t=49337fe8" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="E809BCA5" />
</div>

            <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$smAjaxScriptManager', 'form', [], [], [], 999999, 'ctl00');
//]]>
</script>


            <!--Header-->
            <?php


include "nav.php";


?>

            <!-- /Header -->


            <section>
                

    <!--Page Header-->
    <section class="page-header aboutus_page1"  style="background-image: url(assets/images/newimage/About.png);">
        <div class="container">
            <div class="page-header_wrap">
                <div class="page-heading">
                    <h1>
                        <span id="ContentPlaceHolder_lblTitleHeader">من نحن</span>
                    </h1>
                </div>
                <ul class="coustom-breadcrumb">
                    <li><a href="Home.aspx">
                        <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                    <li>
                        <span id="ContentPlaceHolder_lblTitleHeader2">من نحن</span></li>
                </ul>
            </div>
        </div>
        <!-- Dark Overlay-->
        
    </section>
    <!-- /Page Header-->

    <!--About-us-->
    
    <!-- /About-us-->

    <!-- Why-Choose-Us-->
    <section class="why_choose_us section-padding gray-bg">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="title">لماذا  <span>ماهيندرا</span></h2>
                <p class="body">
                    <span id="ContentPlaceHolder_lblWhydesc"><p class="MsoListParagraph" dir="RTL" style="margin-top:0in;margin-right:.5in;
margin-bottom:8.0pt;margin-left:0in;mso-add-space:auto;text-align:justify;
direction:rtl;unicode-bidi:embed"><font face="Arial, sans-serif"><span style="font-size: 18.6667px;">مجموعة ماهيندرا هي اتحاد عالمي للشركات التي تسعى الى تمكين الناس من النهوض والتطور من خلال حلول مبتكرة صنعت لتقديم تجربة عصرية فريدة من نوعها في عالم التنقل و رعاية الأعمال التجارية الجديدة وتعزيز المجتمعات. في عام 1945 ، بدأت رحلة ماهيندرا, وبعد 75 عامًا توسعت لتشمل 23 صناعة رئيسية. تحتل ماهيندرا موقعًا رياديًا في المركبات متعددة الاستخدامات وتكنولوجيا المعلومات والخدمات المالية وملكية الإجازات في الهند وهي أكبر شركة جرارات في العالم من حيث الحجم. يقع المقر الرئيسي لشركة ماهيندرا في الهند ، وتمتد شبكة ماهيندرا ليعمل بها أكثر من 250,000 شخص في 100 دولة حول العالم.</span></font></p></span>
                </p>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="listing_box">
                        <h5><i class="fa fa-user-circle" aria-hidden="true"></i>
                            <span id="ContentPlaceHolder_lblTrustedByThousands">موثوق به من قبل الآلاف</span>
                        </h5>
                        <p class="body">
                            <span id="ContentPlaceHolder_lblTrustedByThousandsdesc">بعد شراء سيارات ماهيندرا يمكنك صيانتها والتاكد من سلامتها في اي وقت من خلال زيارة الشركة</span>
                        </p>
                    </div>
                    <div class="listing_box">
                        <h5><i class="fa fa-globe" aria-hidden="true"></i>
                            <span id="ContentPlaceHolder_lblWideRangeOfVehicles">مجموعة واسعة من الميزات في المركبات</span>
                        </h5>
                        <p class="body">
                            <span id="ContentPlaceHolder_lblWideRangeOfVehiclesdesc">مع ماهيندرا يمكنك الاستمتاع بجميع المناظر الخلابة و عيش المغامرة اين ما كان طريقك!</span>

                        </p>
                    </div>
                    <div class="listing_box">
                        <h5 ><i class="fa fa-car" aria-hidden="true"></i>
                            <span id="ContentPlaceHolder_lblFasterBuySell">دعم ما بعد البيع</span>
                        </h5>
                        <p class="body">
                            <span id="ContentPlaceHolder_lblFasterBuySelldesc">مع الرغبة المتزايدة في امتلاك السيارات المتميزه وزيادة الطلب على منتجاتنا فيمكنك بسهولة شرائها وبيعها</span>

                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="video_box">
                        <iframe class="mfp-iframe" src="https://www.youtube.com/embed/3Zsyy3JjZME" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Why-Choose-Us-->

    

    

            </section>
            <!-- main-container -->


            <!--Footer -->

        <?php

        include "footer2.php";


?>

            <!-- /Footer-->


            <!--Back to top-->
            <div id="back-top" class="back-top"><a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i></a></div>
            <!--/Back to top-->



            <!--Register-Form -->

            <div class="modal fade" id="signupform">

                <div class="modal-dialog modal-lg" role="document">

                    <div class="modal-content">

                        <div class="modal-header">

                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                            <div style="text-align: center;">
                                <a href="Home.aspx">
                                    <img src="assets/images/logo/Mahindra-Logo.png" width="200" />
                                    </a>
                            </div>
                            <h6 class="modal-title" style="text-align: center;">
                                <span id="lblLetuscallyouandtellyoumoreaboutouroffers">دعنا نتصل بك ونخبرك المزيد عن عروضنا</span></h6>
                            <h3 class="modal-title" style="text-align: center; color: #fa2837;">
                                <span id="lblRequestACallback">طلب استدعاء</span></h3>

                        </div>

                        <div class="modal-body">



                            <div class="signup_wrap">

                                <div class="row">

                                    <div class="col-md-12 col-sm-12">

                                        <div action="#" method="get">

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Full Name">
                                            </div>

                                            <div class="form-group">

                                                <input type="email" class="form-control" placeholder="Email Address">
                                            </div>

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Phone Number">
                                            </div>

                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="">
                                                        <span id="Label24">اتصل بنا</span>Please Select Location</option>
                                                    <option value="DUBAI DEIRA">
                                                        <span id="lblDUBAIDEIRA">دبي ديره</span></option>
                                                </select>
                                                
                                            </div>
                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="Mahindra PIK UP">
                                                        <span id="lblMahindraPIKUP">ماهيندرا بيك أب</span></option>
                                                </select>
                                            </div>
                                            <div class="form-group">

                                                <input type="submit" value="Sign Up" class="btn btn-block">
                                            </div>

                                        </div>

                                    </div>

                                    
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <!--/Register-Form -->


            <!--Schedule-Test-Drive -->
            <div class="modal fade" id="schedule">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblScheduleTestDrive">اختبار القيادة</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$fullName" type="text" id="fullName" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Email" type="email" id="Email" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Phone" type="text" id="Phone" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestTime" type="text" id="BestTime" class="form-control" placeholder="الوقت المفضل (00:00 صباحا)" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestDate" type="text" id="BestDate" class="form-control" placeholder="اليوم المفضل (يوم/شهر/سنة )" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Message" id="Message" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$SubmitSchedule" type="submit" id="SubmitSchedule" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Schedule-Test-Drive -->

            <!--Make-Offer -->
            <div class="modal fade" id="make_offer">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblMakeanOffer">طلب عرض</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemake_offer" type="text" id="FullNamemake_offer" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmake_offer" type="email" id="EmailAddressmake_offer" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermake_offer" type="text" id="PhoneNumbermake_offer" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$OfferPricemake_offer" type="text" id="OfferPricemake_offer" class="form-control" placeholder="سعر العرض" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messageemake_offer" id="Messageemake_offer" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmake_offer" type="submit" id="Submitmake_offer" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Make-Offer -->

            <!--Email-to-Friend -->
            <div class="modal fade" id="email_friend">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblEmailtoFriend">أرسل إلى صديق</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email Address">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Friend Email Address">
                                </div>
                                <div class="form-group">
                                    <textarea rows="4" class="form-control" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Submit Query" class="btn btn-block">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Email-to-Friend -->

            <!--Request-More-Info -->
            <div class="modal fade" id="more_info">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblRequestMoreInfo">طلب مزيد من المعلومات</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemore_info" type="text" id="FullNamemore_info" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmore_info" type="email" id="EmailAddressmore_info" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermore_info" type="text" id="PhoneNumbermore_info" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messagemore_info" id="Messagemore_info" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmore_info" type="submit" id="Submitmore_info" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Request-More-Info -->

        </form>
    </div>

    <!-- Scripts -->

   

<!-- Scripts --> 

<script src="assets/js/jquery.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script> 

<script src="assets/js/interface.js"></script> 

<script src="assets/js/31f5977fdc.js"></script>

<!--Switcher-->

<script src="assets/switcher/js/switcher.js"></script>

<!--bootstrap-slider-JS--> 

<script src="assets/js/bootstrap-slider.min.js"></script> 

<!--Slider-JS--> 

<script src="assets/js/slick.min.js"></script> 

<script src="assets/js/owl.carousel.min.js"></script>
    
    <script>
        //$(document).ready(function () {
        //    debugger;
        //    var loadTime = new Date();
        //    $(document).mouseleave(function () {
        //        var leaveTime = new Date();
        //        var diff = leaveTime - loadTime;
        //        var sec = diff / 1000;
        //        if (sec > 10) {
        //            $('#signupform').addClass("show");
        //            $('#signupform').attr('aria-modal', 'true');
        //            $('#signupform').attr('role', 'dialog');
        //            $('#signupform').css('display', 'block');
        //            $('body').addClass('modal-open');
        //            $('body').css('overflow', 'hidden');
        //            $('body').css('padding-right', '17px');
        //            $('body').append('<div class="modal-backdrop fade show"></div>');

        //        }
        //        loadTime = new Date();
        //    });

        //});
    </script>
</body>
</html>
