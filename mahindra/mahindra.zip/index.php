

<!DOCTYPE html >
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="keywords" /><meta name="description" /><title>
	الرئيسية
</title>

    <!--Bootstrap -->

    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />

    <!--Custome Style -->

    <link rel="stylesheet" href="assets/css/style.css" type="text/css" /><link rel="stylesheet" href="assets/css/custom.css" type="text/css" />

    <!--OWL Carousel slider-->

    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css" /><link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css" />

    <!--slick-slider -->

    <link href="assets/css/slick.css" rel="stylesheet" />

    <!--bootstrap-slider -->

    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet" />

    <!--FontAwesome Font Style -->

    <link href="assets/css/fontawesome.min.css" rel="stylesheet" />



    <!-- SWITCHER -->

    <link rel="stylesheet" type="text/css" href="assets/switcher/css/switcher.css" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" /><link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />



    <!-- Fav and touch icons -->

    <link rel="shortcut icon" href="assets/images/logo/favicon-48x48.ico" />

    <!-- Google-Font-->

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

<![endif]-->

<link href="App_Themes/Theme_Ar/fontfamily.css" type="text/css" rel="stylesheet" /><link href="App_Themes/Theme_Ar/Theme_Ar.css" type="text/css" rel="stylesheet" /></head>
<body class="index2">

    <div class="page-wrapper">

        <form method="post" action="./" id="form" role="form" autocomplete="off">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="W4t2mwfWGgPKQ6yKQD7q82003gqF+i9bhfccBREGR/eK4BjDWoWenwCWJ96yUqHqwxJqKOFwVTYUeXs5LuilOHm9FHPMA/F6d27K9zpubz2o3bGenfFKmc9GS6QWXSIVS5X7vf3vgmqI4XfRp3cy5sOESn8vULCYIBypl01F8ZrfZ+RvuD38dLiHNdEI9TgctYo+3UlLsAo4T/8yXKBq9OIL8/o77JYyuCbjCwyz+NYMyd5uhklylTMomHO5aWY9KWinGmnKBPN/uppxx1hpDL2G0QoheZklIxIL/Xo1RZWX4Xfudpvjm8uV46bEa1g/bj6Xby6MfZ+UliDgNNmVlUsahml5h9gbM6G9mhtb6B8uSzVhd+YluQe4VqSH5+Nsii4/GEgPulx9qP0bTJKwa5M4nM9gEjV3HSsgOoTDghk4DsuSV1BkfXwOtkgblgfOJG85qDBnnE8XauLfm+XIUYlEG2AH+crMlzhgY9Fw4oiVk2HmepIq34wluA46Eze3AB69dTBWeHZK3k49VsAHc0/7muS0dakxW616xNHnTZcv3vyCwYKmBN0dGD0F8afJwedZbCetReZ5NlXoQ/KpQJAg/ppFVJLjw8lJf36nBTUMZMwkdwr/x+oIOqTVHaFSKOo9eW5/9NoePTUwPXuTgPnti9Lz357EUY8u0FyqAvP6k9kUsLBVvnok2dksUHgVLTHleJas6o+P8neM+49xvaRcC1BIVzlwE9mn0uc4OGfY9gSFoz9Cr/XyJ7XLYTl5EvyMi2KapbngOVi2yEsH0Dz/gG05HexHt9wHJawiShG3m2wLul/UVUT6vCjunCvcNejJLe7opbJJUr13vancni3gFom6DImToRSiU7MOMfC+fe9GLsMCXoIRxzimt9sXjl/8H19FY6aVWVHQEiwOGf8ezbb7qfTnCLYEOCTsTl9sZUvwrcsC//HYODp5mAQgC9DUBqEUY0P6FO34tFJhxefXLlvQxTsUkD6A7mNpDzRx4/9yyj9JeQUN3WhY3EeAdUDd8SW7lQ7AQPbsgKLxxeivtdUlnGsWkmMoaW4hwG8I/Hu2yOr6ymvnQe/5f1LQhlERam5jkJVPfPfrfrP/Teu7Jy4f657FzPewDlXP4KyEzsUkvUFAUbv2+4EAnMUsK71Dl8yMzfvEz6635U09Alycd1OtLtC75aCjcPsSs6XBeUTNtydaDsmzqKxRdiap+mAIS5srdvjR6hjuniFPDpLge2QanaT9Ruf+zCkqTsH5+fQ++2HTizNoXjLMFZ4qU56Cxb9vVR5q/OAXoJhvB1fkiHk1rlEAwsSbd/nXZtysARUcmEzS6unkW2/F610srsU30RrNX1qbMrtqOfa1LOTK5w9Aw1Ytlaw55YIEHC016Y1wPm77MzSliYhhBr0wP6OpABpbt5cbIguPsgXI46fa4mF2Uy6lLALC7x6OPcv6xjw1nBpR9wf3DXmspFUyUuO/LAGp8G8eyOyqiZEThaypCMNbuxN+PLqtUUAJvoaWHl9I8c7tp8/8rZP/w9BSAdSMj3HrFlzqAbHipMMj0YlZ/LoD0++DFVB4/t3aMEbyD8tOFfuh/b6OOQmOOf6iBL07UssDapQ/G5PB19NwCn2V6LMA1JCQtNq0gpIUtdm2a+Ee8uBUemtfBjZBI0f9CfxBD+75NQjkbV34zFb302TgBhuQGC2iH0zfVF1QEe3KUMXLS6dCvzO9LqOQ9ZzQSQQwCaYFt7t/II4OPYdhi/onme071HWizwy3T7ddyQEaUq2Bn5goQ8pnWi9kayYMO2l5D1hTN1ZzA4Rnm9QUEBhW4fDy1jrWTCZy/BSfIH/ObK8t6mOw2HULg21gr6RBTkDTdZM4JdpE82JeEPhVb63QOJ7PkCUjNNHVCT+xgbWPlm40SjLpRoxhwg/bP2pTMMSat4AXhO/5NHSuWC+PktAOZRnu5V3xedwLFbuaPv9hjc3NIFYp2DbNLzwfNnIIQrBw8NU08b+9wcCk/OfpJwv6THU9KyOruyIPqnF0JPKMEY0K09PLIjbfSQhHx7VaSDyohll35ZIUPGxMiW59zi1Sf3Ud8EVJJ7vcwb0m+yJoT2Lyu44Xu3hcQ8vwOKgOFYE8N1MboojPsyRjyTeD6uCepAlpkTw4lUBd0OzkOP8d4XCo+Oqe6GHKOHrR40NXkmpi7B1jLELhn1FNvK1pQlTz1jf+8jcA5Fe8CsYZjS4ORER3+iqGceeGSgkIA3Am+WM/z9SaI0k2qN19HTXBvaVuoePtMEAGAdMvIY0YEZzmlwWcK90SqF4D+7jM4DbiddCR2bl7MqyzN9OHBs4oGv3c7L4LQ+x6JIR2iLi7LcnhPftV5jnO4dIZpcA1TTc3q64LU05qOm2iehfdMl79fW7xBRoiljSU8e6FuYX+VbZ1sQDNb0QZWcOWUT5nu7LYIR9uK4kMwINi8STk7ZENhNYQ2/mqmtE99hg2IiuDQ+XQNBhdQL00FlZAxltx7CMRhP9ZcUQGxX19OepCTaREFfJYs9Rv1O8Otm2j08fm3ylPfO918LSdjoBFNw0TA/csDuS2OMb8lFWreWvfBHVs5OnPdhVuaFlgcteRoEpKjo4RVI75LpUTGUIF1VSxrY8DLEHuYRzCkVvkSu2bI1EsdCEuQIKW5xAV32L//Ojoa9kMHueqO/boMVQ/XtjuUFmBF1Hw59zw9oO9wVIvGD6CUdVuzq56KO40r7gdD0ADdnV30KoTkuhkR7Y6VBLoMWfGAIKS3ntf0uU3gzLd7+otqmAeA55yV8hWoaFZZeItB09Zy3ooN8v/Q4l5/tF/TnAR2CLR1I3ogYhc19dzI5CV/3SB+jZ9xS3CX79nrMXE8o2+j2CYh2E/ivHoi/zt7YhGuZOy//L8xA9NGHwpAt939JwRqussn8tJUO0ZI4SLDdgr4VawnsvGuqLuV9kW0pCNdL7iPztHLsaDXoINP4bxShNHD7vg/su0OPRNVDkU5dSjdEW2pfJBy4oRrTv5pu4ziVYieTX0dEnNu2iCIPQ/OMk54pdc/RMlXbRglsr1TIO/XgtO1tzV+AEbWztqeQL9UA2SmjhdlAdxNbAJGZAgdPSV/1PhHQx/nffi2tOH0sTbOmeItqor1aTfuR5G2Ke0oxgmY1kbUIZWd1gpw9S4oStYFDOj4NpBo+xTohL8eHbYBrskmHbBppdYJZViR/WrPdu8RtPa5C/DRdp89D9e/lK7dltr8jFTZlDOcp9icnbGToP2a3N6+S6QX4wq+XFJ+IJS7DRuzYzjY/U6jlOHm8q2s48TEYksRsXjd5Qeh4yiU4OC3nG0RSRuXyyajP6AcdMbafTEb0TrC4LLKK6kwsRwZ3pWBegF5vY/PRh4HnRw9p08sW6pJtzeoGKjWMOXbaoDB92dEWXw34cfZ+nw38sGREmLBf2C514Aq6dgXAa0kenMueqmNauu4IfqU6q57WuXrsOoSBt/ciOcgp6cZvtAbEgWTd34GLfwgVKNOWeA/5uyom1J+M9crIJVHL5LKnwH/4WPOgLLKT2PLDi1dzsA5tl1ivJKNEJrtMwRCXK/VBqCccjESPknft+QiG8TW+kLChgoBFBAyKg3RriOKwJ14GSrmcoyFI4Ly76SOS4IN4l43bl4tHdGY22m5QVBNW1+hxPAjdBxsI7W/8DmnqV+EW9L3j+9gDgWdxv+AeLusFASINxZ2kVyhwo3GxLcWy40mnJBhinFwAiLnOxSXha8+vQfOJ9BRY6U1DCy5OfSr1/I4FLq6MLw17MHNBVULK2VAmZiBerVjmqnm27MpcUvL10hGVMy6yP82zxU5QI1qAZTD2i7clslE7EHD9GGP/rjNf2HoVq/NlRsRZlUFX7p41wieAhNFD1ewbXDUmREM9bt0RxWmeH9bIZ72V/VjTYAlYn/PglyQ3YKPwj3MmtyTv6NYNYPK6URw7hRwxfGzLtTtkyoXJxZwjviJeDBwTxMRZNc++45KXUFxgNC/EJJERLwmhpjByLMTRpySIakuSZVsvu+IPzss/RONjNHPLgkSIh5IKF5PLsn5dpMXJokNZWtXkDhaRJ5CGxR1/DqnJq7XoL+FJMbKca+7wfk4ApnUO7UmrtusBwyzcZbiN0/oS3aY346fb4g+iZTtAQWKEddz2nzdqICD38LVUBkgi5UPKxznw/vzjUKFFgi2KrQwJZBd3bRWromParter/pD9d3PAAOz7HQb5uUpaH1wd/KCSFIzsaAs66+g+8pJ/8rdwU+7n4y21qf1Z7HQMQDQ6iDPnIPaJ4FrIRi3UhkPBBzFM2fMGlZLyDX2KVxeair2M4nHWoGUyLHJAypFlXe73AY5S66MCs+xF9DA9uV4PuyxVNVIFSqNAdVh5SqQu1lAmpP8i7TzKVGij/JM2lE1MMBWcvABb5PV47B45z0Q3TslpzhC0B46O/S8MK2KX7d44cm2Oi+d0Oqmxe3TGoZ3tyJ07UMsfs5nVV6sHH9uW03h5WVvq30dVO2cdCrMcGnklus8NN7bRlzhmRNWvBPqGh3cQrkIYN+Unjsbx5YfLPkucpM53KuYWb6SBytOO0l6nkg4sOFSzbmzyCl92sYaLEY27Co70A4s1ihwGy0euBpaqnII8H/LodewRwNQcYt+IYjOfa4N7QHzEuTAl2eb4lQA2wV9/eJ5IudxnaVYuk7wJ/91KaDJcaxX6fB8tf9ggPlc1VXPhVwtCsUPV6bX3+8JnJsMgF0kMAk7onA0uxDY6s6ddHNiNs5heEzguqkmPCOrjAi6Mf9QqG91K2d8++EmD1yazxlI+jFdAdIVpu39/N/wGe4T29MAmYP4QmJ+L1kmee/cFufsqw3N2s2a1wwGkVDlVEMcv8yHxq/pA5IqHd8MstUaMO3ugJs0anHYGsGz390NHe0CLNf3G4HwXcPWDTOXmp6eYuyK7tgF/dtqAKvujrTxrgJXF4VP6FUubxn6JfKkUb/GqTBkjB2qrw43WbjN771VhoKQILoWk9oMsPt2mxe/XilZ/vn2hizXsHJ6A22O2DxGYQdxVv+89LPRrzjVwVlrGHt74vI806SU6gm2g+fqwLzMQdTKoDWQTPDsg0utNADE1jD4LgkiOD5ILmkfuSVIMYmAwddHtwohynrwNEKVxkMNAYKHgKd7mbe7Ewhk3dNzwRSjsMYuE4hV7gv4mwEbdap68HCxVb/rCe8XPNelPKiMM1b5KCL54GVwImkyPYCg/7AjPSQEccNYRA29CPIGTl94kE9kVj/8b/XqTSclg8WvpPEcFx2eO/6u3zDBrMRL4mcHca+gDXBwdlmwFikISrHX3PVofuLbXCCdYLahpO+ppr2RDKEQJkj9PqJPVboA9ISF8nD4N547gTo2uEBwF5EG4R3Q9YoHu40NjFrkm1j3FH0goUUWSuKhuuDLQz0xrF6fEeXF1B1o90G0R33r1UYYuGBB5y0Ky4rUwSUAL82N8D2mDdpx4juau1ekgiGm3jeZk4RotBILa4V62MkBus5NPcin5L/+joVruUJyacRCkty2PTtzu8yoZ2X8sQQ1ZZPgeuvnRx3WrfU8tRayJojH7QtiSY4acSPpOXD3csubTNlg641Trocb8XjpVDn6MKyMJVNJqxiJjL7bLt9pIC4TGWRf1pUILh+IswbUi2ZtrMP3akBlBQk+DcbaVmsKJRDP2QDX5oV9D7XwGrs7WJknwh1XFoZEWHwh/7BLSAv90F2LK+eslIc6Bjvwbdk+mPIzYcC3P8bYJpo7bKJafC+HIGOCLvBxVWMU1IoBAbzM7SMXeKXDFlPF3DbBc7xQnR1UJg4oIaS4lFy1IBTN9Cv80XWn0ivEq7RqSVWTyS1pwzBUTRSM8a3msTbPyvvtaxRKfjQCSdXmF05AMHmxzy2dyr/zWGMvN4TJob+w+0vuM5BCuVETc+SLPUqkCG0QCoLbexrb4ejyt3dkyPr7juD8FME8rjy7eBZiYiJFegyc5lkrjTUPNCJIOqpF3O3gDsfn1/4hW5S0mVsWqwx9gd52VnpRrgbYchhhT6qmkZX5Wg3xgrMmXAYN8i26C9c80MEV5u4oozJApLI2kn1/0kPXsA8wu0kfUASCV79MghoGJzPyA8AFXJGvOaNOP8xdYsd/t4kuHId" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form'];
if (!theForm) {
    theForm = document.form;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZDpQdIUWfUWblLHx2llNCxzTiz3q8rIrw1SlG64g5YihTxEsBg2&amp;t=637814372020000000" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvvSTvKszaxnqbPz_-DXGRrh6--ASuXVDBt8PX46evQQQMVklpYg8o4D9K3it7MPfj5XdJgnX37-VSZPj7cS0l9i9f2i55c1DsGBMtkBkK3WCfREoxwiCOOdfcUMDb3NE3634uKA1&amp;t=49337fe8" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OOEGMXjf-Mh0VhhBD9Pdi3zBCl51XBH0PP4R4WxYMfih7IFh6hN4KisNC9Ele8QXfNccqGQDHmLR8hfQUwdSzf9wZ7Q75a8vkkLuO5QBxet0ClO4OwUB6ysZ4r2vhoErM45Nz1o1&amp;t=49337fe8" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="8D0E13E6" />
</div>

            <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$smAjaxScriptManager', 'form', [], [], [], 999999, 'ctl00');
//]]>
</script>


            <!--Header-->
            

<?php

include "nav.php";
?>
 

            <!-- /Header -->


            <section>
                



    <!--Banner-->

    <section id="banner2">

        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">

            <!-- Wrapper for slides -->

            <div class="carousel-inner">


                
                        <div class="carousel-item ">

                            <img src='Images/ImageSlider/eea9c318-78ea-49cd-8f71-4a72d609049a.png' class="img-fluid" alt="image">
                            

                            <div class="carousel-caption">

                                <div class="banner_text text-center div_zindex white-text">

                                    <h1></h1>

                                    <h3></h3>

                                </div>

                            </div>

                        </div>
                    
                        <div class="carousel-item active">

                            <img src='Images/ImageSlider/750051a1-c720-4e71-b644-97a15719a310.png' class="img-fluid" alt="image">
                            

                            <div class="carousel-caption">

                                <div class="banner_text text-center div_zindex white-text">

                                    <h1></h1>

                                    <h3></h3>

                                </div>

                            </div>

                        </div>
                    
                        <div class="carousel-item ">

                            <img src='Images/ImageSlider/df8ce1df-6b19-4dcb-9c33-5140cb340903.png' class="img-fluid" alt="image">
                            

                            <div class="carousel-caption">

                                <div class="banner_text text-center div_zindex white-text">

                                    <h1></h1>

                                    <h3></h3>

                                </div>

                            </div>

                        </div>
                    
                        <div class="carousel-item ">

                            <img src='Images/ImageSlider/3fbf13f4-31be-4f38-ab55-146f04fed30e.png' class="img-fluid" alt="image">
                            

                            <div class="carousel-caption">

                                <div class="banner_text text-center div_zindex white-text">

                                    <h1></h1>

                                    <h3></h3>

                                </div>

                            </div>

                        </div>
                    





                
            </div>



            <!-- Controls -->

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">

                <span class="carousel-control-prev-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Previous</span>

            </button>

            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">

                <span class="carousel-control-next-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Next</span>

            </button>

        </div>

    </section>

    <!--/Banner-->

    <!-- Filter-Form -->

    <section id="filter_form2">

        <div class="container">

            <div class="main_bg white-text">

                <h3>
                    <span id="ContentPlaceHolder_lblFindYourDreamCar">ابحث عن سيارة أحلامك</span>
                </h3>



                <div>

                    <div class="row">

                        <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option value="">
                                        <span id="ContentPlaceHolder_lblSelectLocation">اختر الفرع</span></option>

                                    <option value="Khobar">
                                        <span id="ContentPlaceHolder_lblDUBAIDEIRA">الخبر</span>
                                    </option>

                                </select>

                            </div>

                        </div>

                          <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option>
                                        <span id="ContentPlaceHolder_lblSelectModel">نوع السيارة</span></option>

                                    <option>
                                        <span id="ContentPlaceHolder_lblMahindraPIKUPselect">بيك اب</span></option>

                                </select>

                            </div>

                        </div>
                        <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option>
                                        <span id="ContentPlaceHolder_lblSelectBrand">حدد الفئة</span></option>

                                    <option>غمارة دفع ثنائي</option>  
                                    <option>غمارة دفع رباعي</option> 
                                    <option>غمارتين دفع ثنائي</option> 
                                    <option>غمارتين دفع رباعي</option>

                                </select>

                            </div>

                        </div>
                        <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option>
                                       ناقل الحركة</option>

                                    <option>يدوي</option>  
                                    <option>اوتوماتيك</option> 

                                </select>

                            </div>

                        </div>
                        <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option>
                                        نوع المحرك</option>

                                    <option>ديزل s6</option>  
                                    <option>ديزل s11</option> 

                                </select>

                            </div>

                        </div>
                      

                        <div class="form-group col-md-3 col-sm-6">

                            <div class="select">

                                <select class="form-control">

                                    <option>
                                        <span id="ContentPlaceHolder_lblYearofModel">سنة الصنع</span>
                                    </option>

                                   

                                    <option>2023</option>

                                </select>

                            </div>

                        </div>



                        




                        

                        <div class="form-group col-md-6 col-sm-6">

                            <a class="btn btn-block" href="VehiclesDetail.php?ID=1">
                                <i class="fa fa-search" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblSearchCar">عرض  السيارة</span>
                            </a>

                        </div>

                    </div>

                </div>



            </div>

        </div>

    </section>

    <!-- /Filter-Form -->





    <!--About-us-->

    <section id="about_us" class="section-padding">

        <div class="container">

            <div class="section-header text-center">

                <h2 class="title">
                    <span id="ContentPlaceHolder_lblWelcometomahindrauaeuae">مرحبا بكم في ماهيندرا </span></h2>

                <p class="body">
                    <span id="ContentPlaceHolder_lblAboutdesc"><p class="MsoListParagraph" dir="RTL" style="margin-top:0in;margin-right:.5in;
margin-bottom:8.0pt;margin-left:0in;mso-add-space:auto;text-align:justify;
direction:rtl;unicode-bidi:embed"><font face="Arial, sans-serif"><span style="font-size: 18.6667px;">مجموعة ماهيندرا هي اتحاد عالمي للشركات التي تسعى الى تمكين الناس من النهوض والتطور من خلال حلول مبتكرة صنعت لتقديم تجربة عصرية فريدة من نوعها في عالم التنقل و رعاية الأعمال التجارية الجديدة وتعزيز المجتمعات. في عام 1945 ، بدأت رحلة ماهيندرا, وبعد 75 عامًا توسعت لتشمل 23 صناعة رئيسية. تحتل ماهيندرا موقعًا رياديًا في المركبات متعددة الاستخدامات وتكنولوجيا المعلومات والخدمات المالية وملكية الإجازات في الهند وهي أكبر شركة جرارات في العالم من حيث الحجم. يقع المقر الرئيسي لشركة ماهيندرا في الهند ، وتمتد شبكة ماهيندرا ليعمل بها أكثر من 250,000 شخص في 100 دولة حول العالم.</span></font></p></span>
                    
                </p>

            </div>



            <div class="row">

                <div class="col-md-3 col-sm-6">

                    <div class="about_info">

                        <div class="icon_box">

                            <i class="fa fa-money" aria-hidden="true"></i>

                        </div>

                        <h5>
                            <span id="ContentPlaceHolder_lblBestPrice">افضل الاسعار</span></h5>

                        

                    </div>

                </div>



                <div class="col-md-3 col-sm-6">

                    <div class="about_info">

                        <div class="icon_box">

                            <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>

                        </div>

                        <h5>
                            <span id="ContentPlaceHolder_lblFasterBuySell">موثوق به من قبل الآلاف</span></h5>

                       

                    </div>

                </div>



                <div class="col-md-3 col-sm-6">

                    <div class="about_info">

                        <div class="icon_box">

                            <i class="fa fa-history" aria-hidden="true"></i>

                        </div>

                        <h5>
                            <span id="ContentPlaceHolder_lblFreeSupport">دعم ما بعد البيع</span></h5>

                      

                    </div>

                </div>



                <div class="col-md-3 col-sm-6">

                    <div class="about_info">

                        <div class="icon_box">

                            <i class="fa fa-users" aria-hidden="true"></i>

                        </div>

                        <h5>
                            <span id="ContentPlaceHolder_lblProfessionalDealers">تجار محترفون</span></h5>

                       

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!--/About-us-->



    <!--Fan-Fact-->

    <section id="fun-facts" class="dark-bg vc_row">

        <div class=" col-md-6 vc_col section-padding">

            <div class="fact_m white-text">

                <h2 class="title">
                    <span id="ContentPlaceHolder_lblMahindraPIKUP">ماهيندرا  بيك اب</span></h2>

                <p class="body">
                    <span id="ContentPlaceHolder_lblAHEAVENLYVIEW">نظرة ساحرة ...</span><br />
                    <span id="ContentPlaceHolder_lblATHEAVENLYPRICE">بأسعار مذهلة</span>
                </p>
                

            </div>

        </div>

        <div class=" col-md-6 vc_col section-padding about ">

            <div class="facts_section_bg"></div>

        </div>

    </section>

    <!--/Fan-fact-->



    











    <!--Blog -->

    <section class="section-padding" style="display:none;">

        <div class="container">

            <div class="section-header text-center">

                <h2>
                    <span id="ContentPlaceHolder_lblLatest">آخر التحديثات في صناعة السيارات</span></h2>

                <p>
                    <span id="ContentPlaceHolder_lblLatestDesc">
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.
                    </span>

                </p>

            </div>

            <div class="row">
                
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/cad967b5-1fdf-4a6a-b179-d4fa83e7982f.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>إدارة منصات وسائل الإعلام الاجتماعية.</a></h5>

                            <p>ندير الحسابات لإظهار وجودك وتمثيلك على النحو المطلوب وفقًا لخطط المحتوى المختلفة</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/b25b0c16-125e-4fb2-880c-f0d368aac763.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>بناء هوية بصرية</a></h5>

                            <p>نقوم بإنشاء الحضور المرئي لشركتك من خلال العناصر المرتبطة بالشعار والمنتجات والخدمات للعلامة التجارية أو المنشأة التي تمثلها</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/16ee4f6c-f03f-49a1-a435-df2ab91746c4.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>بحوث وسائل الإعلام ودراسات الرأي العام</a></h5>

                            <p>نقدم البحوث والدراسات وفق خطوات وتكتيكات تنسجم مع منظور علمي</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/435c5aee-2610-48fd-971e-f2d6c3972785.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>إدارة حملات الاتصالات</a></h5>

                            <p>نحدد الجمهور المستهدف ، ونطور رسائل الاتصال ، وننتج المحتوى المناسب ، ونحدد قنوات النشر</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/88415ba8-f23c-40ec-94ec-6df6e12a8398.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>صناعة المحتوى</a></h5>

                            <p>نبحر في المخيلة لخلق محتوى مبتكر وحديث يلبي متطلبات العميل</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/08c6015e-5d8f-4415-b046-94a3d658bfe3.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>مراقبة وتحليل الوسائط</a></h5>

                            <p>نراقب ونحلل ما يتم تداوله على منصات التواصل الاجتماعي ونعرضه في تقارير منظمة لاستخدامها في تخطيط أو قياس اتجاهات الرأي العام.</p>

                            
                        </div>

                    </article>

                </div>
                    
                        <div class="col-md-4 col-sm-4">

                    <article class="blog-list">

                        <div class="blog-info-box">

                            
                            <img src='Images/NEWS/45fdb324-d1c2-49d4-89d0-405672f8270b.jpg' class="img-fluid" alt="image">
                            

                            <ul>

                                

                                <li><i class="fa fa-calendar" aria-hidden="true"></i>19/08/2022</li>

                                
                            </ul>

                        </div>

                        <div class="blog-content">

                            <h5><a>تخطيط استراتيجي</a></h5>

                            <p>نحن نبني ونطور الخطط الإستراتيجية لعملائنا بما يتماشى مع رؤيتهم وأهدافهم</p>

                            
                        </div>

                    </article>

                </div>
                    
                

                
            </div>
        </div>
    </section>

    <!-- /Blog-->



    <!--Brands-->

    

    <!-- /Brands-->
    <!-- Help-Number-->

    <section id="help" class="section-padding">

        <div class="container">

            <div class="div_zindex white-text text-center" style=" direction: ltr; ">

                <h2 class="title">
                    <span id="ContentPlaceHolder_lblHaveAnyQuestion">هل لديك اي سؤال؟</span><br>
                    <span id="ContentPlaceHolder_lblPhoneFooter" style=" direction: ltr; ">+966554045535</span>
                </h2>

            </div>

        </div>



        <!-- Dark-overlay-->

        <div class="dark-overlay"></div>

    </section>

    <!-- /Help-Number-->



            </section>
            <!-- main-container -->


            <!--Footer -->

          <?php

include "footer1.php";

?>

            <!-- /Footer-->


            <!--Back to top-->
            <div id="back-top" class="back-top"><a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i></a></div>
            <!--/Back to top-->



            <!--Register-Form -->

            <div class="modal fade" id="signupform">

                <div class="modal-dialog modal-lg" role="document">

                    <div class="modal-content">

                        <div class="modal-header">

                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                            <div style="text-align: center;">
                                <a href="index.php">
                                    <img src="assets/images/logo/Mahindra-Logo.png" width="200" />
                                    </a>
                            </div>
                            <h6 class="modal-title" style="text-align: center;">
                                <span id="lblLetuscallyouandtellyoumoreaboutouroffers">دعنا نتصل بك ونخبرك المزيد عن عروضنا</span></h6>
                            <h3 class="modal-title" style="text-align: center; color: #fa2837;">
                                <span id="lblRequestACallback">طلب استدعاء</span></h3>

                        </div>

                        <div class="modal-body">



                            <div class="signup_wrap">

                                <div class="row">

                                    <div class="col-md-12 col-sm-12">

                                        <div action="#" method="get">

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Full Name">
                                            </div>

                                            <div class="form-group">

                                                <input type="email" class="form-control" placeholder="Email Address">
                                            </div>

                                            <div class="form-group">

                                                <input type="text" class="form-control" placeholder="Phone Number">
                                            </div>

                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="">
                                                        <span id="Label24">اتصل بنا</span>Please Select Location</option>
                                                    <option value="DUBAI DEIRA">
                                                        <span id="lblDUBAIDEIRA">دبي ديره</span></option>
                                                </select>
                                                
                                            </div>
                                            <div class="form-group">
                                                <select name="location" class="form-control">
                                                    <option value="Mahindra PIK UP">
                                                        <span id="lblMahindraPIKUP">ماهيندرا بيك أب</span></option>
                                                </select>
                                            </div>
                                            <div class="form-group">

                                                <input type="submit" value="Sign Up" class="btn btn-block">
                                            </div>

                                        </div>

                                    </div>

                                    
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <!--/Register-Form -->


            <!--Schedule-Test-Drive -->
            <div class="modal fade" id="schedule">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblScheduleTestDrive">اختبار القيادة</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$fullName" type="text" id="fullName" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Email" type="email" id="Email" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Phone" type="text" id="Phone" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestTime" type="text" id="BestTime" class="form-control" placeholder="الوقت المفضل (00:00 صباحا)" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$BestDate" type="text" id="BestDate" class="form-control" placeholder="اليوم المفضل (يوم/شهر/سنة )" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Message" id="Message" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$SubmitSchedule" type="submit" id="SubmitSchedule" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Schedule-Test-Drive -->

            <!--Make-Offer -->
            <div class="modal fade" id="make_offer">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblMakeanOffer">طلب عرض</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemake_offer" type="text" id="FullNamemake_offer" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmake_offer" type="email" id="EmailAddressmake_offer" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermake_offer" type="text" id="PhoneNumbermake_offer" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$OfferPricemake_offer" type="text" id="OfferPricemake_offer" class="form-control" placeholder="سعر العرض" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messageemake_offer" id="Messageemake_offer" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmake_offer" type="submit" id="Submitmake_offer" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Make-Offer -->

            <!--Email-to-Friend -->
            <div class="modal fade" id="email_friend">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblEmailtoFriend">أرسل إلى صديق</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email Address">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Friend Email Address">
                                </div>
                                <div class="form-group">
                                    <textarea rows="4" class="form-control" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Submit Query" class="btn btn-block">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Email-to-Friend -->

            <!--Request-More-Info -->
            <div class="modal fade" id="more_info">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title">
                                <span id="lblRequestMoreInfo">طلب مزيد من المعلومات</span></h3>
                        </div>
                        <div class="modal-body">
                            <div action="#" method="get">
                                <div class="form-group">
                                    <input name="ctl00$FullNamemore_info" type="text" id="FullNamemore_info" class="form-control" placeholder="السم بلكامل" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$EmailAddressmore_info" type="email" id="EmailAddressmore_info" class="form-control" placeholder="بريدك الالكتروني" />
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$PhoneNumbermore_info" type="text" id="PhoneNumbermore_info" class="form-control" placeholder="رقم الهاتف" />
                                </div>
                                <div class="form-group">
                                    <textarea name="ctl00$Messagemore_info" id="Messagemore_info" rows="4" class="form-control" placeholder="الرسالة"></textarea>
                                </div>
                                <div class="form-group">
                                    <input name="ctl00$Submitmore_info" type="submit" id="Submitmore_info" value="ارسال" class="btn btn-block" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Request-More-Info -->

        </form>
    </div>

    <!-- Scripts -->

   

<!-- Scripts --> 

<script src="assets/js/jquery.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script> 

<script src="assets/js/interface.js"></script> 

<script src="assets/js/31f5977fdc.js"></script>

<!--Switcher-->

<script src="assets/switcher/js/switcher.js"></script>

<!--bootstrap-slider-JS--> 

<script src="assets/js/bootstrap-slider.min.js"></script> 

<!--Slider-JS--> 

<script src="assets/js/slick.min.js"></script> 

<script src="assets/js/owl.carousel.min.js"></script>
    
    <script>
        //$(document).ready(function () {
        //    debugger;
        //    var loadTime = new Date();
        //    $(document).mouseleave(function () {
        //        var leaveTime = new Date();
        //        var diff = leaveTime - loadTime;
        //        var sec = diff / 1000;
        //        if (sec > 10) {
        //            $('#signupform').addClass("show");
        //            $('#signupform').attr('aria-modal', 'true');
        //            $('#signupform').attr('role', 'dialog');
        //            $('#signupform').css('display', 'block');
        //            $('body').addClass('modal-open');
        //            $('body').css('overflow', 'hidden');
        //            $('body').css('padding-right', '17px');
        //            $('body').append('<div class="modal-backdrop fade show"></div>');

        //        }
        //        loadTime = new Date();
        //    });

        //});
    </script>
</body>
</html>
