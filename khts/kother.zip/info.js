 


var phn="966534206222";
var end_date="29-1-2023";
var end_time="12:00";
var ad_source="snap ";
var action_url="https://script.google.com/macros/s/AKfycbyVinuzcYNmoU1OqwBN0r_idjUbA1aD5_9vUz9rLWFBu7UiiWJn4N9JbGg72iBnBWvCLw/exec";







 