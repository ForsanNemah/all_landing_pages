<div style="padding-bottom:12%; position:relative; display:block; width: 100%">
  <iframe width="100%" height="100%"
    src="count_down/index.html"
    frameborder="0" allowfullscreen="" style="position:absolute; top:0; left: 0">
  </iframe>
</div>
<h3>
  

<?php

			include 'info.php';
			
			 echo $info['counter_message'];
			
			
			
			
			?>




</h3>
