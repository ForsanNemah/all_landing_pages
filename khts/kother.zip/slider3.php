<h2> كادر طبي خبير</h2>
<br>

<div id="myCarousel3" class="carousel slide" data-ride="carousel"  >
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarouse3" data-slide-to="0" class="active"></li>
      <li data-target="#myCarouse3" data-slide-to="1"></li>
      <li data-target="#myCarouse3" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" >

	
      

      <div class="item active">
        
		<img src="ads/dr1asnan.jpg"class="img-responsive" alt="Responsive image"   >
		
      </div>

      <div class="item  ">
        
        <img src="ads/dr2asnan.jpg"class="img-responsive" alt="Responsive image"   >
        
          </div>

          <div class="item  ">
        
        <img src="ads/dr3asnan.jpg"class="img-responsive" alt="Responsive image"   >
        
          </div>

          <div class="item  ">
        
        <img src="ads/dr4asnan.jpg"class="img-responsive" alt="Responsive image"   >
        
          </div>
    
       

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel3" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel3" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>

  </div>
  
  </div>