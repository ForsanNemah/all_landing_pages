 


var phn="966568430828";
var end_date="20-3-2023";
var end_time="12:00";
var ad_source="facebook ";
var action_url="https://script.google.com/macros/s/AKfycbwt_0qKBPtxODkfduY_8rdMN76zdspxVqJTq7exD0aT9VhowX_h3nUn98gUPDJK_YaoeQ/exec";






 